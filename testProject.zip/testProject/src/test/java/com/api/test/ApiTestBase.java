package com.api.test;

import org.apache.log4j.Logger;
import org.testng.annotations.BeforeTest;

import com.enums.Constants;
import com.enums.Environments;

public class ApiTestBase {
	protected String baseUrl ;
	protected static Logger LOG = Logger.getLogger(ApiTestBase.class);
	
	@BeforeTest(alwaysRun = true)
	public void beforeApiSuitOperations() {
		baseUrl = Environments.getApiUrlForEnv(System.getProperty(Constants.ENV_STRING));
	}
}
