package com.api.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

import com.enums.Constants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.pojo.SpotTradeObj;
import com.pojo.TradeResponse;
import com.pojo.ValidateBatchRequestPojo;
import com.utils.JsonUtils;
import com.utils.api.RestApiManager;
import com.utils.api.RestRequestBuilder;

import io.restassured.response.Response;

public class ApiTestWithoutDP extends ApiTestBase {

	ObjectMapper mapper = new ObjectMapper();

	/**
	 * Below Method validates 400 Bad request status for validateBatch Api if the
	 * value date is empty
	 * Removing the timestamp validation, though the timestamp added dinamically to
	 * the expected response, it differs by 15+ milliseconds.
	 * 
	 * @throws Exception
	 */

	@Test
	public void postValidateValueDateEmptyApiTest() throws Exception {
		RestRequestBuilder request = new RestRequestBuilder().setBaseURI(baseUrl).getRequestBuilderWithNoAuthContentTyeAsJson();
		RestApiManager apiManager = new RestApiManager(request);
		SpotTradeObj requestPojo = mapper.readValue(JsonUtils.getResourceFile(Constants.VALIDATE_REQUEST_JSON_FILE_NAME), SpotTradeObj.class);
		requestPojo.setValueDate(" ");
		Response response = apiManager.sendRequest(Constants.POST_METHOD, Constants.VALIDATE_END_POINT, requestPojo);
		assertEquals(response.getStatusCode(), 400, Constants.STATUS_CODE_NOT_MATCH_EMPTY_VALUE_DATE_STRING);
		JsonObject expectedresponseJsonObj = JsonUtils.getJsonObjectFromResources(Constants.VALUE_DATE_400_RESPONSE_JSON_FILE_NAME);
		// expectedresponseJsonObj.addProperty("timestamp", new
		// Timestamp(System.currentTimeMillis()).getTime());
		expectedresponseJsonObj.remove(Constants.TIMESTAMP_STRING);
		JsonObject actualJsonObj = JsonUtils.convertStringToJson(response.asString()).getAsJsonObject();
		actualJsonObj.remove(Constants.TIMESTAMP_STRING);
		JsonUtils.validateJsonObjects(JsonUtils.convertStringToJson(actualJsonObj.toString()), JsonUtils.convertStringToJson(expectedresponseJsonObj.toString()));
	}

	/*****
	 * Below Method validates 200 Ok status for validate batch Api
	 * @throws Exception
	 */

	@Test
	public void postValidateBatchApiTest() throws Exception {
		RestRequestBuilder request = new RestRequestBuilder().setBaseURI(baseUrl).getRequestBuilderWithNoAuthContentTyeAsJson();
		RestApiManager apiManager = new RestApiManager(request);
		List<ValidateBatchRequestPojo> requestPojoList = mapper.readValue(JsonUtils.getResourceFile(Constants.VALIDATE_BATCH_REQUEST_JSON_FILE_NAME),
				new TypeReference<List<ValidateBatchRequestPojo>>() {});
		Response response = apiManager.sendRequest(Constants.POST_METHOD, Constants.VALIDATE_BATCH_END_POINT, requestPojoList);
		assertEquals(response.getStatusCode(), 200, Constants.STATUS_CODE_NOT_MATCH_STRING);
		TradeResponse[] actualResponsePojoList = response.as(TradeResponse[].class);
		TradeResponse[] expectedResponsePojoList = mapper.readValue(JsonUtils.getResourceFile(Constants.VALIDATE_BATCH_RESPONSE_JSON_FILE_NAME), TradeResponse[].class);
		LOG.info("Actual Pojo " + actualResponsePojoList);
		LOG.info("Expected pojo" + expectedResponsePojoList);
		assertTrue(Arrays.equals(actualResponsePojoList, expectedResponsePojoList));
	}

}
