package com.api.test;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.Map;

import org.testng.annotations.Test;

import com.dataproviders.DataProviders;
import com.enums.Constants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pojo.BasePojoObj;
import com.pojo.ForwardTradeObj;
import com.pojo.OptionTradeObj;
import com.pojo.SpotTradeObj;
import com.pojo.TradeResponse;
import com.utils.JsonUtils;
import com.utils.api.RestApiManager;
import com.utils.api.RestRequestBuilder;

import io.restassured.response.Response;

public class ApiTestsWithDP extends ApiTestBase {

	ObjectMapper mapper = new ObjectMapper();

	/**
	 * This method will test all the  spot trade related api validations.
	 * The test data is coming from DataSpotTrade.xls
	 * @param map
	 * @throws Exception
	 */
	@Test(dataProvider = Constants.DATA_PROVIDER_NAME_SPOT_DATA, dataProviderClass = DataProviders.class)
	public void validateSoptTests(Map<String, String> map) throws Exception {
		runApis(map, SpotTradeObj.class);
	}
	
	/**
	 * This method will test all the  forward trade related api validations.
	 * The test data is coming from DataForwardTrade.xls
	 * @param map
	 * @throws Exception
	 */

	@Test(dataProvider = Constants.DATA_PROVIDER_NAME_FORWARD_DATA, dataProviderClass = DataProviders.class)
	public void validateForwardTests(Map<String, String> map) throws Exception {
		runApis(map, ForwardTradeObj.class);
	}
	
	/**
	 * This method will test all the  option trade related api validations.
	 * The test data is coming from DataOptionTrade.xls
	 * @param map
	 * @throws Exception
	 */

	@Test(dataProvider = Constants.DATA_PROVIDER_NAME_OPTION_DATA, dataProviderClass = DataProviders.class)
	public void validateOptionTests(Map<String, String> map) throws Exception {
		runApis(map, OptionTradeObj.class);
	}

	private <T extends BasePojoObj> void runApis(Map<String, String> map, Class<T> class1) throws Exception {
		map.remove(Constants.DATA_MAP_PARAM_TEST_NAME);
		String requestMethod = map.get(Constants.DATA_MAP_PARAM_METHOD_NAME);
		map.remove(Constants.DATA_MAP_PARAM_METHOD_NAME);
		String endPoint = map.get(Constants.DATA_MAP_PARAM_END_POINT);
		map.remove(Constants.DATA_MAP_PARAM_END_POINT);
		String stausCode = map.get(Constants.DATA_MAP_PARAM_STATUS_CODE);
		map.remove(Constants.DATA_MAP_PARAM_STATUS_CODE);
		String responseStatus = map.get(Constants.DATA_MAP_PARAM_RESPONSE_STATUS);
		map.remove(Constants.DATA_MAP_PARAM_RESPONSE_STATUS);
		String responseMessages = map.get(Constants.DATA_MAP_PARAM_RESPONSE_MSG);
		map.remove(Constants.DATA_MAP_PARAM_RESPONSE_MSG);
		BasePojoObj requestPojo = JsonUtils.getTradeObjFromMapValues(class1, map);
		RestRequestBuilder request = new RestRequestBuilder().setBaseURI(baseUrl).getRequestBuilderWithNoAuthContentTyeAsJson();
		RestApiManager apiManager = new RestApiManager(request);
		Response response = apiManager.sendRequest(requestMethod, endPoint, requestPojo);
		assertEquals(response.getStatusCode(), Integer.parseInt(stausCode), Constants.STATUS_CODE_NOT_MATCH_STRING + endPoint);
		assertEquals(response.getBody().jsonPath().get("status").toString(), responseStatus, "Status message Mismatch ");
		// TradeResponse expectedPojo =
		// mapper.readValue(JsonUtils.getResourceFile("schema/tradeResponse.json"),
		// TradeResponse.class);
		TradeResponse actualResponsePojo = response.as(TradeResponse.class);
		if (responseMessages.equals("null")) {
			LOG.info("Asserting NULL " + actualResponsePojo.getMessages());
			assertTrue(null == actualResponsePojo.getMessages());
		} else {
			LOG.info("Asserting Message " + actualResponsePojo.getMessages().toString());
			assertEquals(actualResponsePojo.getMessages().toString(), responseMessages);
		}
	}

}
