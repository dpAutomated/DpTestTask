package com.api.test;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import com.dataproviders.DataProviders;
import com.enums.Constants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.utils.JsonUtils;
import com.utils.api.RestApiManager;
import com.utils.api.RestRequestBuilder;

import io.restassured.response.Response;

public class ApiTest extends ApiTestBase {

	ObjectMapper mapper = new ObjectMapper();

	/**
	 * Below test take inputs from data provider for all of the apis available in
	 * the Data.xls
	 * We can test all the apis using the approach provided in the method
	 * @param endPoint
	 * @param requestMethod
	 * @param requestBody
	 * @param expectedresponseJson
	 */

	@Test(dataProvider = Constants.DATA_PROVIDER_NAME_DATA, dataProviderClass = DataProviders.class)
	public void testAllApis(String endPoint, String requestMethod, String stausCode, String requestBody, String expectedresponseJson) {
		RestRequestBuilder request = new RestRequestBuilder().setBaseURI(baseUrl).getRequestBuilderWithNoAuthContentTyeAsJson();
		RestApiManager apiManager = new RestApiManager(request);
		Response response = apiManager.sendRequest(requestMethod, endPoint, requestBody);
		assertEquals(response.getStatusCode(), Integer.parseInt(stausCode), Constants.STATUS_CODE_NOT_MATCH_STRING + endPoint);
		JsonUtils.validateJsonObjects(JsonUtils.convertStringToJson(response.asString()), JsonUtils.convertStringToJson(expectedresponseJson));
	}
}
