package com.enums;


public class Constants {
	
	public static final String API_BASE_URL_TEST_ENV="http://localhost:12345/";
	
	public static final String DATA_MAP_PARAM_TEST_NAME = "TestName";
	public static final String DATA_MAP_PARAM_METHOD_NAME = "RequestMethod";
	public static final String DATA_MAP_PARAM_END_POINT = "EndPoint";
	public static final String DATA_MAP_PARAM_STATUS_CODE= "StatusCode";
	public static final String DATA_MAP_PARAM_RESPONSE_STATUS = "ResponseStatus";
	public static final String DATA_MAP_PARAM_RESPONSE_MSG = "ResponseMessages";
	
	public static final String DATA_PROVIDER_NAME_DATA = "Data";
	public static final String DATA_PROVIDER_NAME_SPOT_DATA ="MapDataSpot";
	public static final String DATA_PROVIDER_NAME_FORWARD_DATA ="MapDataForward";
	public static final String DATA_PROVIDER_NAME_OPTION_DATA ="MapDataOption";
	
	public static final String FILE_NAME_DATA_XLS = "testdata/data.xls";
	public static final String FILE_NAME_DATA_SPOT_TRADE_XLS="testdata/DataSpotTrade.xls";
	public static final String FILE_NAME_DATA_FORWARD_TRADE_XLS="testdata/DataForwardTrade.xls";
	public static final String FILE_NAME_DATA_OPTION_TRADE_XLS="testdata/DataOptionTrade.xls";
	
	public static final String STATUS_CODE_NOT_MATCH_STRING = " Status code is not matching ";
	public static final String STATUS_CODE_NOT_MATCH_EMPTY_VALUE_DATE_STRING = " Status code is not matching for empty value date";
	
	public static final String ENV_STRING= "env";
	
	public static final String POST_METHOD = "post";
	public static final String GET_METHOD = "get";
	
	public static final String VALIDATE_END_POINT = "/validate";
	public static final String VALIDATE_BATCH_END_POINT = "/validateBatch";
	
	public static final String VALIDATE_REQUEST_JSON_FILE_NAME="schema/validateRequest.json";
	public static final String VALUE_DATE_400_RESPONSE_JSON_FILE_NAME="schema/tradeResponseValueDate400.json";
	public static final String VALIDATE_BATCH_REQUEST_JSON_FILE_NAME="schema/validateBatchRequest.json";
	public static final String VALIDATE_BATCH_RESPONSE_JSON_FILE_NAME="schema/tradeResponseBatch.json";
	
	public static final String TIMESTAMP_STRING = "timestamp";

	public static final String EXTENT_REPORT_FILENAME = "ExtentReportTestNg.html";
	public static final String EXTENT_REPORT_CONFIG_FILE_NAME = "extent-config.xml";

}
