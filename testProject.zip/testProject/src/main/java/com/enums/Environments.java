package com.enums;

import java.util.function.Function;

public enum Environments {

	//ENUM_NAME ("Key","webUrl","apiUrl")
	TEST("TEST", "testWebUrl",
    		   Constants.API_BASE_URL_TEST_ENV),
    UAT("UAT", "testUrl",
             "test1Url");  
	
	private String key;
	private String apiUrl;

	private Environments(String key, String webUrl, String apiUrl) {
		this.key = key;
		this.apiUrl = apiUrl;

	}

	private static String extract(String key, Function<Environments, String> logic) {
		for (Environments value : values()) {
			if (value.getKey().equals(key)) {
				return logic.apply(value);
			}
		}
		throw new IllegalArgumentException("Incorrect value: " + key);
	}

	public static String getApiUrlForEnv(String key) {
		return extract(key, value -> value.getApiURl());
	}

	public String getApiURl() {
		return apiUrl;
	}

	public String getKey() {
		return key;
	}

}


