package com.utils.api;

import com.enums.Constants;

import io.restassured.response.Response;

public class RestApiManager {


    private RestRequestBuilder requestBuilder;
    

    public RestApiManager(RestRequestBuilder requestBuilder) {
        this.requestBuilder = requestBuilder;
    }

    public Response sendGetRequest(String resourceUrl) {
        Response response = requestBuilder.getRequestSpecification().get(resourceUrl);
        //response.prettyPrint();
        return response;

    }

    public <T> Response sendRequest(String requestMethod, String resourceUrl, T requestBody) {
    	Response response =null;
    	if(requestMethod.equals(Constants.GET_METHOD))
    		response = sendGetRequest(resourceUrl);
    	if(requestMethod.equals(Constants.POST_METHOD))
    		response = sendPostRequest(resourceUrl, requestBody);
    	return response;
    }
    
    public <T> Response sendPostRequest(String resourceUrl, T requestBody) {
        Response response = requestBuilder.getRequestSpecification().body(requestBody).post(resourceUrl);
        response.prettyPrint();
        return response;
    }

    public Response sendPostRequest(String resourceUrl) {
        Response response = requestBuilder.getRequestSpecification().post(resourceUrl);
        response.prettyPrint();
        return response;
    }

    public <T> Response sendPutRequest(String resourceUrl, T requestBody) {
        Response response = requestBuilder.getRequestSpecification().body(requestBody).put(resourceUrl);
        response.prettyPrint();
        return response;
    }

    public Response sendPutRequest(String resourceUrl) {
        Response response = requestBuilder.getRequestSpecification().put(resourceUrl);
        response.prettyPrint();
        return response;
    }

}
