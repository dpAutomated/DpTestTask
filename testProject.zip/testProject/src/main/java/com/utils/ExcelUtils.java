package com.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {

	private static XSSFWorkbook excelXWBook;
	private static XSSFSheet excelXWSheet;
	private static Cell cell;

	private static HSSFWorkbook excelSWBook;
	private static HSSFSheet excelSWSheet;
	private static HSSFRow rowS;

	private static String excelFilePath;

	public static void openExcelFile(File file) {
		excelFilePath = file.getPath();

		System.out.println("=====================" + excelFilePath);

		try(InputStream stream = new FileInputStream(file)) {
			//InputStream stream = new FileInputStream(file);
			if (excelFilePath.endsWith(".xls")) {

				excelSWBook = new HSSFWorkbook(stream);
				excelSWSheet = excelSWBook.getSheetAt(0);

			} else if (excelFilePath.endsWith(".xlsx")) {
				excelXWBook = new XSSFWorkbook(stream);
				excelXWSheet = excelXWBook.getSheetAt(0);

			}

		} catch (Exception e) {
			e.getMessage();

		}
	}

	public static int getnumberOfColumns() {
		int noOfColumns = -1;
		try {

			if (null != excelSWBook) {

				noOfColumns = excelSWSheet.getRow(0).getLastCellNum();
			} else if (null != excelXWBook) {

				noOfColumns = excelXWSheet.getRow(0).getLastCellNum();
			}

			return noOfColumns;

		} catch (Exception e) {
			e.getMessage();

			return 0;
		}
	}

	public static String[][] getSheetData() {
		DataFormatter formatter = new DataFormatter();
		int rowNum = excelSWSheet.getPhysicalNumberOfRows();
		int colNum = getnumberOfColumns();
		System.out.println("######### No of rows  " + rowNum + "   ######## no of cols  " + colNum);
		String data[][] = new String[rowNum - 1][colNum];

		for (int i = 0; i < rowNum - 1; i++) // Loop work for Rows
		{
			HSSFRow row = excelSWSheet.getRow(i + 1);

			for (int j = 0; j < colNum; j++) // Loop work for colNum
			{
				if (row == null)
					data[i][j] = "";
				else {
					HSSFCell cell = row.getCell(j);
					if (cell == null)
						data[i][j] = ""; // if it get Null value it pass no data
					else {
						String value = formatter.formatCellValue(cell);
						data[i][j] = value; // This formatter get my all values as string i.e integer, float all type data
											// value
					}
				}
			}
		}

		return data;
	}
	
	
	public static Object[][] getSheetDataAsMap() {
		DataFormatter formatter = new DataFormatter();
		int rowNum = excelSWSheet.getPhysicalNumberOfRows();
		int colNum = getnumberOfColumns();
		System.out.println("######### No of rows  " + rowNum + "   ######## no of cols  " + colNum);
		Object data[][] = new Object[rowNum - 1][1];

		for (int i = 0; i < rowNum - 1; i++) // Loop work for Rows
		{
			Map<String, String> datamap = new HashMap<>();
			HSSFRow row = excelSWSheet.getRow(i + 1);

			for (int j = 0; j < colNum; j++) // Loop work for colNum
			{
				if (row == null)
					data[i][j] = "";
				else {
					HSSFCell cell = row.getCell(j);
					if (cell == null)
						data[i][j] = ""; // if it get Null value it pass no data
					else {
						String value = formatter.formatCellValue(cell);
						 datamap.put(excelSWSheet.getRow(0).getCell(j).toString(), value);
					}
				}
			}
			data[i][0] = datamap; 
		}
		return data;
	}
}
