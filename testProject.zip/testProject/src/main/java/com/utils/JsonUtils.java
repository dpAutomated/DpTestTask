package com.utils;

import static org.junit.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.pojo.BasePojoObj;
import com.pojo.SpotTradeObj;

import io.restassured.response.Response;

public class JsonUtils {
    private static Logger LOG = Logger.getLogger(JsonUtils.class);

    public static String getJsonParamValue() {
        return null;
    }

    /**
     * Please make sure that the actual and expected Json are of same structure
     *
     * @param actualJson
     * @param expectedJson
     */
    public static void validateJsonObjects(JsonElement actualJson, JsonElement expectedJson) {
        if (actualJson.isJsonArray() && expectedJson.isJsonArray()) {
            JsonArray actualJsonArray = actualJson.getAsJsonArray();
            JsonArray expectedJsonArray = expectedJson.getAsJsonArray();

            for (int i = 0, len = expectedJsonArray.size(); i < len; i++) {
                validateJsonObjects(expectedJsonArray.get(i), actualJsonArray.get(i));
            }

        } else if (actualJson.isJsonObject() && expectedJson.isJsonObject()) {

            Set<Entry<String, JsonElement>> expectedObjEntrySet = ((JsonObject) expectedJson).entrySet();

            for (Entry<String, JsonElement> en : expectedObjEntrySet) {
                if (en.getValue().isJsonObject() && ((JsonObject) actualJson).get(en.getKey()).isJsonObject()) {
                    validateJsonObjects(en.getValue(), ((JsonObject) actualJson).get(en.getKey()));
                } else if (en.getValue().isJsonArray() && ((JsonObject) actualJson).get(en.getKey()).isJsonArray()) {
                    validateJsonObjects(en.getValue(), ((JsonObject) actualJson).get(en.getKey()));
                } else {
                    JsonObject actualJsonObj = actualJson.getAsJsonObject();
                    JsonObject expectedJsonObj = expectedJson.getAsJsonObject();
                    LOG.info("******** "+en.getKey() + " : Actual Json value :" + actualJsonObj.get(en.getKey()) + " Expected Json value : "
                            + expectedJsonObj.get(en.getKey()));
                    assertEquals("Incorrect Response for " + en.getKey() + " : ", actualJsonObj.get(en.getKey()),
                            expectedJsonObj.get(en.getKey()));
                }
            }
        }else if(actualJson.isJsonPrimitive() && expectedJson.isJsonPrimitive()){
        	LOG.info("Asserting premitives Expected: "+expectedJson.getAsJsonPrimitive().getAsString()+" and Actual is "+actualJson.getAsJsonPrimitive().getAsString());
        	assertEquals("Incorrect Response for " + expectedJson.getAsJsonPrimitive().getAsString() + " : ", actualJson.getAsJsonPrimitive().getAsString(),
        			expectedJson.getAsString());
        }else if(actualJson.isJsonNull()) {
        	LOG.info("Asserting Json null");
        	assertTrue(expectedJson.isJsonNull());
        }
    }

    public static JsonObject getJsonObjectFromResources(String fileName) {
        JsonParser parser = new JsonParser();
        JsonObject jObj = null;
        try (FileReader reader = new FileReader(new File(Res.getResource(fileName).toURI()))) {
            jObj = parser.parse(reader).getAsJsonObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jObj;
    }
    
    public static File getResourceFile(String fileName) {
        File file= null;
		try {
			file = new File(Res.getResource(fileName).toURI());
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
        return file;
        
    }

    public static JsonElement convertResponseToJson(Response response) {
        JsonParser parser = new JsonParser();
        return parser.parse(response.body().toString());
    }
    
    public static JsonElement convertStringToJson(String json) {
        JsonParser parser = new JsonParser();
        return parser.parse(json);
    }

	public static <T extends BasePojoObj> BasePojoObj getTradeObjFromMapValues(Class<T> class1, Map<String, String> map) {
		ObjectMapper mapper = new ObjectMapper(); // jackson's objectmapper
		BasePojoObj pojo = mapper.convertValue(map, class1);
		return pojo;
	}

}
