package com.dataproviders;

import java.io.File;

import org.testng.annotations.DataProvider;

import com.enums.Constants;
import com.utils.ExcelUtils;

public class DataProviders {
	
	@DataProvider(name=Constants.DATA_PROVIDER_NAME_DATA)
	public Object[][] getDataFromDataprovider() throws Exception{
		ExcelUtils.openExcelFile(new File(Thread.currentThread().getContextClassLoader().getResource(Constants.FILE_NAME_DATA_XLS).toURI()));
		return ExcelUtils.getSheetData();
	}
	
	@DataProvider(name=Constants.DATA_PROVIDER_NAME_SPOT_DATA)
	public Object[][] getDataFromDataproviderForSpotTrade() throws Exception{
		ExcelUtils.openExcelFile(new File(Thread.currentThread().getContextClassLoader().getResource(Constants.FILE_NAME_DATA_SPOT_TRADE_XLS).toURI()));
		return ExcelUtils.getSheetDataAsMap();
	}
	
	@DataProvider(name=Constants.DATA_PROVIDER_NAME_FORWARD_DATA)
	public Object[][] getDataFromDataproviderForFOrwardTrade() throws Exception{
		ExcelUtils.openExcelFile(new File(Thread.currentThread().getContextClassLoader().getResource(Constants.FILE_NAME_DATA_FORWARD_TRADE_XLS).toURI()));
		return ExcelUtils.getSheetDataAsMap();
	}
	
	@DataProvider(name=Constants.DATA_PROVIDER_NAME_OPTION_DATA)
	public Object[][] getDataFromDataproviderForOptionTrade() throws Exception{
		ExcelUtils.openExcelFile(new File(Thread.currentThread().getContextClassLoader().getResource(Constants.FILE_NAME_DATA_OPTION_TRADE_XLS).toURI()));
		return ExcelUtils.getSheetDataAsMap();
	}

}
