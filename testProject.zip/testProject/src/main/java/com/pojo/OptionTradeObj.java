package com.pojo;

public class OptionTradeObj extends BasePojoObj {

private String customer;
private String ccyPair;
private String type;
private String style;
private String direction;
private String strategy;
private String tradeDate;
private Float amount1;
private Float amount2;
private Float rate;
private String deliveryDate;
private String expiryDate;
private String payCcy;
private Float premium;
private String premiumCcy;
private String premiumType;
private String premiumDate;
private String legalEntity;
private String trader;

public String getCustomer() {
return customer;
}

public void setCustomer(String customer) {
this.customer = customer;
}

public String getCcyPair() {
return ccyPair;
}

public void setCcyPair(String ccyPair) {
this.ccyPair = ccyPair;
}

public String getType() {
return type;
}

public void setType(String type) {
this.type = type;
}

public String getStyle() {
return style;
}

public void setStyle(String style) {
this.style = style;
}

public String getDirection() {
return direction;
}

public void setDirection(String direction) {
this.direction = direction;
}

public String getStrategy() {
return strategy;
}

public void setStrategy(String strategy) {
this.strategy = strategy;
}

public String getTradeDate() {
return tradeDate;
}

public void setTradeDate(String tradeDate) {
this.tradeDate = tradeDate;
}

public Float getAmount1() {
return amount1;
}

public void setAmount1(Float amount1) {
this.amount1 = amount1;
}

public Float getAmount2() {
return amount2;
}

public void setAmount2(Float amount2) {
this.amount2 = amount2;
}

public Float getRate() {
return rate;
}

public void setRate(Float rate) {
this.rate = rate;
}

public String getDeliveryDate() {
return deliveryDate;
}

public void setDeliveryDate(String deliveryDate) {
this.deliveryDate = deliveryDate;
}

public String getExpiryDate() {
return expiryDate;
}

public void setExpiryDate(String expiryDate) {
this.expiryDate = expiryDate;
}

public String getPayCcy() {
return payCcy;
}

public void setPayCcy(String payCcy) {
this.payCcy = payCcy;
}

public Float getPremium() {
return premium;
}

public void setPremium(Float premium) {
this.premium = premium;
}

public String getPremiumCcy() {
return premiumCcy;
}

public void setPremiumCcy(String premiumCcy) {
this.premiumCcy = premiumCcy;
}

public String getPremiumType() {
return premiumType;
}

public void setPremiumType(String premiumType) {
this.premiumType = premiumType;
}

public String getPremiumDate() {
return premiumDate;
}

public void setPremiumDate(String premiumDate) {
this.premiumDate = premiumDate;
}

public String getLegalEntity() {
return legalEntity;
}

public void setLegalEntity(String legalEntity) {
this.legalEntity = legalEntity;
}

public String getTrader() {
return trader;
}

public void setTrader(String trader) {
this.trader = trader;
}

/* (non-Javadoc)
 * @see java.lang.Object#hashCode()
 */
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((amount1 == null) ? 0 : amount1.hashCode());
	result = prime * result + ((amount2 == null) ? 0 : amount2.hashCode());
	result = prime * result + ((ccyPair == null) ? 0 : ccyPair.hashCode());
	result = prime * result + ((customer == null) ? 0 : customer.hashCode());
	result = prime * result + ((deliveryDate == null) ? 0 : deliveryDate.hashCode());
	result = prime * result + ((direction == null) ? 0 : direction.hashCode());
	result = prime * result + ((expiryDate == null) ? 0 : expiryDate.hashCode());
	result = prime * result + ((legalEntity == null) ? 0 : legalEntity.hashCode());
	result = prime * result + ((payCcy == null) ? 0 : payCcy.hashCode());
	result = prime * result + ((premium == null) ? 0 : premium.hashCode());
	result = prime * result + ((premiumCcy == null) ? 0 : premiumCcy.hashCode());
	result = prime * result + ((premiumDate == null) ? 0 : premiumDate.hashCode());
	result = prime * result + ((premiumType == null) ? 0 : premiumType.hashCode());
	result = prime * result + ((rate == null) ? 0 : rate.hashCode());
	result = prime * result + ((strategy == null) ? 0 : strategy.hashCode());
	result = prime * result + ((style == null) ? 0 : style.hashCode());
	result = prime * result + ((tradeDate == null) ? 0 : tradeDate.hashCode());
	result = prime * result + ((trader == null) ? 0 : trader.hashCode());
	result = prime * result + ((type == null) ? 0 : type.hashCode());
	return result;
}

/* (non-Javadoc)
 * @see java.lang.Object#equals(java.lang.Object)
 */
@Override
public boolean equals(Object obj) {
	if (this == obj) {
		return true;
	}
	if (obj == null) {
		return false;
	}
	if (!(obj instanceof OptionTradeObj)) {
		return false;
	}
	OptionTradeObj other = (OptionTradeObj) obj;
	if (amount1 == null) {
		if (other.amount1 != null) {
			return false;
		}
	} else if (!amount1.equals(other.amount1)) {
		return false;
	}
	if (amount2 == null) {
		if (other.amount2 != null) {
			return false;
		}
	} else if (!amount2.equals(other.amount2)) {
		return false;
	}
	if (ccyPair == null) {
		if (other.ccyPair != null) {
			return false;
		}
	} else if (!ccyPair.equals(other.ccyPair)) {
		return false;
	}
	if (customer == null) {
		if (other.customer != null) {
			return false;
		}
	} else if (!customer.equals(other.customer)) {
		return false;
	}
	if (deliveryDate == null) {
		if (other.deliveryDate != null) {
			return false;
		}
	} else if (!deliveryDate.equals(other.deliveryDate)) {
		return false;
	}
	if (direction == null) {
		if (other.direction != null) {
			return false;
		}
	} else if (!direction.equals(other.direction)) {
		return false;
	}
	if (expiryDate == null) {
		if (other.expiryDate != null) {
			return false;
		}
	} else if (!expiryDate.equals(other.expiryDate)) {
		return false;
	}
	if (legalEntity == null) {
		if (other.legalEntity != null) {
			return false;
		}
	} else if (!legalEntity.equals(other.legalEntity)) {
		return false;
	}
	if (payCcy == null) {
		if (other.payCcy != null) {
			return false;
		}
	} else if (!payCcy.equals(other.payCcy)) {
		return false;
	}
	if (premium == null) {
		if (other.premium != null) {
			return false;
		}
	} else if (!premium.equals(other.premium)) {
		return false;
	}
	if (premiumCcy == null) {
		if (other.premiumCcy != null) {
			return false;
		}
	} else if (!premiumCcy.equals(other.premiumCcy)) {
		return false;
	}
	if (premiumDate == null) {
		if (other.premiumDate != null) {
			return false;
		}
	} else if (!premiumDate.equals(other.premiumDate)) {
		return false;
	}
	if (premiumType == null) {
		if (other.premiumType != null) {
			return false;
		}
	} else if (!premiumType.equals(other.premiumType)) {
		return false;
	}
	if (rate == null) {
		if (other.rate != null) {
			return false;
		}
	} else if (!rate.equals(other.rate)) {
		return false;
	}
	if (strategy == null) {
		if (other.strategy != null) {
			return false;
		}
	} else if (!strategy.equals(other.strategy)) {
		return false;
	}
	if (style == null) {
		if (other.style != null) {
			return false;
		}
	} else if (!style.equals(other.style)) {
		return false;
	}
	if (tradeDate == null) {
		if (other.tradeDate != null) {
			return false;
		}
	} else if (!tradeDate.equals(other.tradeDate)) {
		return false;
	}
	if (trader == null) {
		if (other.trader != null) {
			return false;
		}
	} else if (!trader.equals(other.trader)) {
		return false;
	}
	if (type == null) {
		if (other.type != null) {
			return false;
		}
	} else if (!type.equals(other.type)) {
		return false;
	}
	return true;
}

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "OptionTradeObj [customer=" + customer + ", ccyPair=" + ccyPair + ", type=" + type + ", style=" + style + ", direction=" + direction + ", strategy=" + strategy
			+ ", tradeDate=" + tradeDate + ", amount1=" + amount1 + ", amount2=" + amount2 + ", rate=" + rate + ", deliveryDate=" + deliveryDate + ", expiryDate=" + expiryDate
			+ ", payCcy=" + payCcy + ", premium=" + premium + ", premiumCcy=" + premiumCcy + ", premiumType=" + premiumType + ", premiumDate=" + premiumDate + ", legalEntity="
			+ legalEntity + ", trader=" + trader + "]";
}

}