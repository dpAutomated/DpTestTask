package com.pojo;


public class ForwardTradeObj extends BasePojoObj{

private String customer;
private String ccyPair;
private String type;
private String direction;
private String tradeDate;
private Float amount1;
private Float amount2;
private Float rate;
private String valueDate;
private String legalEntity;
private String trader;

public String getCustomer() {
return customer;
}

public void setCustomer(String customer) {
this.customer = customer;
}

public String getCcyPair() {
return ccyPair;
}

public void setCcyPair(String ccyPair) {
this.ccyPair = ccyPair;
}

public String getType() {
return type;
}

public void setType(String type) {
this.type = type;
}

public String getDirection() {
return direction;
}

public void setDirection(String direction) {
this.direction = direction;
}

public String getTradeDate() {
return tradeDate;
}

public void setTradeDate(String tradeDate) {
this.tradeDate = tradeDate;
}

public Float getAmount1() {
return amount1;
}

public void setAmount1(Float amount1) {
this.amount1 = amount1;
}

public Float getAmount2() {
return amount2;
}

public void setAmount2(Float amount2) {
this.amount2 = amount2;
}

public Float getRate() {
return rate;
}

public void setRate(Float rate) {
this.rate = rate;
}

public String getValueDate() {
return valueDate;
}

public void setValueDate(String valueDate) {
this.valueDate = valueDate;
}

public String getLegalEntity() {
return legalEntity;
}

public void setLegalEntity(String legalEntity) {
this.legalEntity = legalEntity;
}

public String getTrader() {
return trader;
}

public void setTrader(String trader) {
this.trader = trader;
}

/* (non-Javadoc)
 * @see java.lang.Object#hashCode()
 */
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((amount1 == null) ? 0 : amount1.hashCode());
	result = prime * result + ((amount2 == null) ? 0 : amount2.hashCode());
	result = prime * result + ((ccyPair == null) ? 0 : ccyPair.hashCode());
	result = prime * result + ((customer == null) ? 0 : customer.hashCode());
	result = prime * result + ((direction == null) ? 0 : direction.hashCode());
	result = prime * result + ((legalEntity == null) ? 0 : legalEntity.hashCode());
	result = prime * result + ((rate == null) ? 0 : rate.hashCode());
	result = prime * result + ((tradeDate == null) ? 0 : tradeDate.hashCode());
	result = prime * result + ((trader == null) ? 0 : trader.hashCode());
	result = prime * result + ((type == null) ? 0 : type.hashCode());
	result = prime * result + ((valueDate == null) ? 0 : valueDate.hashCode());
	return result;
}

/* (non-Javadoc)
 * @see java.lang.Object#equals(java.lang.Object)
 */
@Override
public boolean equals(Object obj) {
	if (this == obj) {
		return true;
	}
	if (obj == null) {
		return false;
	}
	if (!(obj instanceof ForwardTradeObj)) {
		return false;
	}
	ForwardTradeObj other = (ForwardTradeObj) obj;
	if (amount1 == null) {
		if (other.amount1 != null) {
			return false;
		}
	} else if (!amount1.equals(other.amount1)) {
		return false;
	}
	if (amount2 == null) {
		if (other.amount2 != null) {
			return false;
		}
	} else if (!amount2.equals(other.amount2)) {
		return false;
	}
	if (ccyPair == null) {
		if (other.ccyPair != null) {
			return false;
		}
	} else if (!ccyPair.equals(other.ccyPair)) {
		return false;
	}
	if (customer == null) {
		if (other.customer != null) {
			return false;
		}
	} else if (!customer.equals(other.customer)) {
		return false;
	}
	if (direction == null) {
		if (other.direction != null) {
			return false;
		}
	} else if (!direction.equals(other.direction)) {
		return false;
	}
	if (legalEntity == null) {
		if (other.legalEntity != null) {
			return false;
		}
	} else if (!legalEntity.equals(other.legalEntity)) {
		return false;
	}
	if (rate == null) {
		if (other.rate != null) {
			return false;
		}
	} else if (!rate.equals(other.rate)) {
		return false;
	}
	if (tradeDate == null) {
		if (other.tradeDate != null) {
			return false;
		}
	} else if (!tradeDate.equals(other.tradeDate)) {
		return false;
	}
	if (trader == null) {
		if (other.trader != null) {
			return false;
		}
	} else if (!trader.equals(other.trader)) {
		return false;
	}
	if (type == null) {
		if (other.type != null) {
			return false;
		}
	} else if (!type.equals(other.type)) {
		return false;
	}
	if (valueDate == null) {
		if (other.valueDate != null) {
			return false;
		}
	} else if (!valueDate.equals(other.valueDate)) {
		return false;
	}
	return true;
}

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "ForwardTradeObj [customer=" + customer + ", ccyPair=" + ccyPair + ", type=" + type + ", direction=" + direction + ", tradeDate=" + tradeDate + ", amount1=" + amount1
			+ ", amount2=" + amount2 + ", rate=" + rate + ", valueDate=" + valueDate + ", legalEntity=" + legalEntity + ", trader=" + trader + "]";
}

}