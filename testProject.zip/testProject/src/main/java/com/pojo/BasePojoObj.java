package com.pojo;


public class BasePojoObj {

}
