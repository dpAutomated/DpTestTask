package com.pojo;

public class TradeBatchResponse {

private String status;
private Object messages;

public String getStatus() {
return status;
}

public void setStatus(String status) {
this.status = status;
}

public Object getMessages() {
return messages;
}

public void setMessages(Object messages) {
this.messages = messages;
}

/* (non-Javadoc)
 * @see java.lang.Object#hashCode()
 */
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((messages == null) ? 0 : messages.hashCode());
	result = prime * result + ((status == null) ? 0 : status.hashCode());
	return result;
}

/* (non-Javadoc)
 * @see java.lang.Object#equals(java.lang.Object)
 */
@Override
public boolean equals(Object obj) {
	if (this == obj) {
		return true;
	}
	if (obj == null) {
		return false;
	}
	if (!(obj instanceof TradeBatchResponse)) {
		return false;
	}
	TradeBatchResponse other = (TradeBatchResponse) obj;
	if (messages == null) {
		if (other.messages != null) {
			return false;
		}
	} else if (!messages.equals(other.messages)) {
		return false;
	}
	if (status == null) {
		if (other.status != null) {
			return false;
		}
	} else if (!status.equals(other.status)) {
		return false;
	}
	return true;
}

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "TradeBatchResponse [status=" + status + ", messages=" + messages + "]";
}

}